<!DOCTYPE html>
<!--Code by Divinector (www.divinectorweb.com)-->
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Homepage</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="home.css">    
</head>
<body>
    <header>
    <div class="wrapper">
        <div class="logo">
            <img src="https://cdn.w600.comps.canstockphoto.com/cross-logo-medical-spine-diagnostic-eps-vector_csp63874941.jpg" alt="">
        </div>
<ul class="nav-area">
<li><a href="#">Home</a></li>
<li><a href="#">About us</a></li>
<li><a href="admin_login.php">Admin</a></li>
<li><a href="clinic_login.php">Clinic</a></li>
<li><a href="register.php">User</a></li>

</ul>
</div>
<div class="welcome-text">
        <h1>
Diagnosis <span>Management System</span></h1>
<a href="#">Contact US</a>
    </div>
</header>

</body>
</html>

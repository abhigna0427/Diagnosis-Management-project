<!DOCTYPE html>
<html>
<head>
  <link rel="stylesheet" type="text/css" href="user_front.css">
  <meta charset="utf-8">
  <title>user_front</title>
</head>
<body>
   <div class="menu-bar"><ul class="nav-area">
<li><a href="home.php">Home</a></li>
<li><a href="#">About us</a></li>
<li><a href="login.php">Log Out</a></li>
</ul>

      <h1>Diagnosis And Test Management System</h1>

  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

  <br>
  <br>
  <br>
  <br>
  <br>

<div class="info"><p>This text is the content of the box. We have added a 50px padding, 20px margin and a 15px green border. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p></div>

  <div class="main">
  <div class="cards">
         <div a href="book.php"   class="image">
          <img src="https://images.everydayhealth.com/images/cancer/leukemia/cancer-diagnosis-and-tests-722x406.jpg">

         </div>

          <div class="title">
           <a href="book.php" class="title">  <h2>BOOK APPOINTMENT</h2></a>
            
           </div>
  </div>


<div class="cards">
         <div class="image">
         <img src="https://www.chirayuhospital.org/images/hp.png">
         </div>

          <div class="title">
          <a href="book.php" class="title"> <h2>View Clinics</h2> </a>
           </div>
  </div>

<div class="cards">
         <div class="image">
         <img src="https://i2.wp.com/www.additudemag.com/wp-content/uploads/2006/12/GettyImages-1129223269.jpg?resize=1280%2C720px&ssl=1">
         </div>

          <div class="title">
           <h2>REPORTS</h2>
           </div>
  </div>

  <div class="cards">
         <div class="image">
         <img src="https://www.redrocketmg.com/wp-content/uploads/phone2.png">
         </div>

          <div class="title">
           <h2>View Tests</h2>
           </div>
  </div>
 </div>
</body>
</html>
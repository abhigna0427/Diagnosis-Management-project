<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="../css/add_test.css">
	<meta charset="utf-8">
	<title>add_test</title>
</head>
<body>
	<div class="center">
    <h1 align="center">ADD TESTS</h1>
    <form method="post">
    <div class="txt_field">
   <input type="text" required>
   <span></span>
   <label>TEST ID</label>
    </div>
  
    <div class="txt_field">
   <input type="text" required>
   <span></span>
   <label>TEST NAME</label>
    </div>

    <div class="txt_field">
   <input type="text" required>
   <span></span>
   <label>SAMPLE</label>
    </div>

    <div class="txt_field">
   <input type="text" required>
   <span></span>
   <label>DURATION</label>
    </div>  

    <div class="txt_field">
   <input type="password" required>
   <span></span>
   <label>AMOUNT</label>
    </div>

    
   
    <input type="submit" value="ADD TEST">
    <div class="signup_link">
    	
    </div>
</form>
    </div>	

</body>
</html>